public class Store {

}
