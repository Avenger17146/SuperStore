import java.io.*;
import java.util.Scanner;

public class Amacon implements Serializable{

    public static void SerializeDB(Database db) throws IOException {
        ObjectOutputStream oStream = null;

        try {
            oStream = new ObjectOutputStream(new FileOutputStream("DB.dat"));
            oStream.writeObject(db);
            System.out.println("File saved");
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        finally {
            oStream.close();
        }
    }

    public static Database DeserializeDB() throws IOException, ClassNotFoundException {
        ObjectInputStream inputStream = null;
        Database db = null;

        try{
            inputStream = new ObjectInputStream(new FileInputStream("DB.dat"));
            db = (Database) inputStream.readObject();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());

        }
        finally {
            inputStream.close();
        }

        return db;
    }




    public static void main(String[] args)
    {
        Database database = null;
        try
        {
            database  = DeserializeDB();
        }
        catch ( Exception e )
        {
            System.out.println(e.getMessage());
            database = new Database();
        }
        if ( database == null)
            database = new Database();
        Administrator administrator = new Administrator(database);
        int a = 0;
        Scanner s = new Scanner(System.in);
        while ( a == 0)
        {
            System.out.println("1. Insert product/category\n" +
                    "2. Delete product/category\n" +
                    "3. Search product\n" +
                    "4. Modify product\n" +
                    "5. Exit as Administrator");
            int d = s.nextInt();
            switch(d)
            {
                case 1 : database = administrator.Insert();
                         break;
                case 2 : database =administrator.Delete();
                         break;
                case 3 : administrator.Search();
                         break;
                case 4 : database = administrator.Modify();
                         break;
                case 5 : a = 1;
                         break;
            }
        }

        System.out.println("Enter Customer ID");
        String cid = s.next();
        Customer customer = new Customer(database,cid);
        while ( a == 1)
        {

            System.out.println("1. Add funds (assume all integer operations)\n" +
                    "2. Add product to the cart\n" +
                    "3. Check-out cart\n" +
                    "4. Exit as Customer");
            int d = s.nextInt();
            switch (d)
            {
                case 1 : System.out.println("Enter amount to be added");
                         int b = s.nextInt();
                         customer.addFunds(b);
                         //
                         break;
                case 2 : customer.addProduct();
                         break;
                case 3 : database = customer.checkout();
                         break;
                case 4 : a = 2;
                         customer.write();
                    try {
                        SerializeDB(database);
                    }
                    catch (Exception e)
                    {
                        e.getMessage();
                    }
                         break;
            }
        }
        System.out.println("revenue : " + database.getRevenue());

    }
}
